package com.bdd.calculadora;

import static org.junit.Assert.assertEquals;

import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;

public class CalcSteps {
	
	Calc calculadora;
	int num1,num2;

	@Dado("^que eu escolha somar$")
	public void que_eu_escolha_somar() {
	    // Write code here that turns the phrase above into concrete actions
	    calculadora = new Calc();
	}

	@Quando("^eu preencho o primeiro número com valor '(\\d+)'$")
	public void eu_preencho_o_primeiro_número_com_valor(int arg1) {
	    // Write code here that turns the phrase above into concrete actions
		num1 = arg1;
	    
	}

	@Quando("^eu preencho o segundo número com '(\\d+)'$")
	public void eu_preencho_o_segundo_número_com(int arg1) {
	    // Write code here that turns the phrase above into concrete actions
	    num2 = arg1;
	}

	@Então("^eu devo ver o resultado como '(\\d+)'$")
	public void eu_devo_ver_o_resultado_como(int arg1) {
	    // Write code here that turns the phrase above into concrete actions

	    assertEquals(arg1, calculadora.somar(num1, num2));
	}

	
}
